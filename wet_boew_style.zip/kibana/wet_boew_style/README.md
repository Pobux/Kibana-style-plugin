# Kibana plugin for wet boew styles
